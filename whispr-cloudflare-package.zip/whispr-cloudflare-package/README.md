# Whispr — Cloudflare Workers package

This is the production-built Whispr app for **Cloudflare Workers**. It includes the server-rendered Worker and its static files. It is not a static Cloudflare Pages upload.

## Deploy

1. Extract this ZIP on your computer.
2. Install Node.js if it is not already installed.
3. Open a terminal in the extracted `whispr-cloudflare-package` folder.
4. Run:

   ```sh
   npx wrangler deploy
   ```

5. Sign in to Cloudflare when Wrangler asks, then choose your Cloudflare account. Wrangler will publish the Worker and print its `workers.dev` address.

If you have already installed Wrangler, you can run `wrangler deploy` instead.

## Before sign-in can work on the Cloudflare address

Whispr continues to use its existing Lovable Cloud service for accounts, messages, and data. After deployment, add the exact Cloudflare site origin (for example, `https://your-worker.workers.dev`) to the app's authentication redirect allow-list in Lovable, then test email, Google, and Lovable sign-in on that address. The final allow-list value depends on the address Cloudflare gives you.

## Security and scope

- No `.env` file, passwords, private keys, or server-only credentials are included.
- The app's public browser connection settings are part of its client build; those are intended to be visible to browsers and are not private credentials.
- Existing data and user accounts stay in Lovable Cloud; this package does not export or move them.
- Set a custom domain in Cloudflare after the first deployment if desired, and allow-list that origin for sign-in too.
