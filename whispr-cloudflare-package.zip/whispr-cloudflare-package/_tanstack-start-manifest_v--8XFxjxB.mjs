//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v--8XFxjxB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bw3AxF1F.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bw3AxF1F.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dw8xvURh.js"]
	}
} });
//#endregion
export { tsrStartManifest };
