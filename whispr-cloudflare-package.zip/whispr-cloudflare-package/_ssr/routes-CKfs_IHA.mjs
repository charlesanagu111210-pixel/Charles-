import { n as __toESM } from "../_runtime.mjs";
import { h as require_react, m as require_jsx_runtime, n as AvatarFallback$1, o as Slot, r as AvatarImage$1, t as Avatar$1 } from "../_libs/@radix-ui/react-avatar+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as supabase } from "./client-BXcPdpHb.mjs";
import { t as createLovableAuth } from "../_libs/lovable.dev__cloud-auth-js.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Send, c as Phone, d as Ellipsis, f as CircleUserRound, i as ShieldAlert, l as MessageCircle, m as ArrowLeft, n as Video, o as Search, p as Check, r as Shield, s as Plus, t as X, u as LogOut } from "../_libs/lucide-react.mjs";
import { a as ScrollAreaViewport, i as ScrollAreaThumb, n as ScrollAreaCorner, r as ScrollAreaScrollbar, t as ScrollArea$1 } from "../_libs/radix-ui__react-scroll-area.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CKfs_IHA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var lovableAuth = createLovableAuth();
var lovable = { auth: { signInWithOAuth: async (provider, opts) => {
	const result = await lovableAuth.signInWithOAuth(provider, {
		...opts,
		extraParams: { ...opts?.extraParams }
	});
	if (result.redirected) return result;
	if (result.error) return result;
	try {
		await supabase.auth.setSession(result.tokens);
	} catch (e) {
		return { error: e instanceof Error ? e : new Error(String(e)) };
	}
	return result;
} } };
function isValidUsername(username) {
	return /^[A-Za-z0-9_]{3,20}$/.test(username);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Avatar = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar$1, {
	ref,
	className: cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
	...props
}));
Avatar.displayName = Avatar$1.displayName;
var AvatarImage = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage$1, {
	ref,
	className: cn("aspect-square h-full w-full", className),
	...props
}));
AvatarImage.displayName = AvatarImage$1.displayName;
var AvatarFallback = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback$1, {
	ref,
	className: cn("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
	...props
}));
AvatarFallback.displayName = AvatarFallback$1.displayName;
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScrollArea$1, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaViewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaCorner, {})
	]
}));
ScrollArea.displayName = ScrollArea$1.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var whispr_conversation_default = "/assets/whispr-conversation-B9XBW7PA.jpg";
function Whispr() {
	const [user, setUser] = (0, import_react.useState)(null);
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [contacts, setContacts] = (0, import_react.useState)([]);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [profileLoaded, setProfileLoaded] = (0, import_react.useState)(false);
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(false);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [blocked, setBlocked] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [loginMode, setLoginMode] = (0, import_react.useState)("signin");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [authError, setAuthError] = (0, import_react.useState)("");
	const [resetSent, setResetSent] = (0, import_react.useState)(false);
	const [recovery, setRecovery] = (0, import_react.useState)(false);
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [recoveryError, setRecoveryError] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [usernameError, setUsernameError] = (0, import_react.useState)("");
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [founderOpen, setFounderOpen] = (0, import_react.useState)(false);
	const [searchName, setSearchName] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [savedName, setSavedName] = (0, import_react.useState)("");
	const [founderPin, setFounderPin] = (0, import_react.useState)("");
	const [founderError, setFounderError] = (0, import_react.useState)("");
	const [founderData, setFounderData] = (0, import_react.useState)(null);
	const [mobileChat, setMobileChat] = (0, import_react.useState)(false);
	const [callState, setCallState] = (0, import_react.useState)(null);
	const [callVideo, setCallVideo] = (0, import_react.useState)(false);
	const [callStatus, setCallStatus] = (0, import_react.useState)("");
	const [, setCallTick] = (0, import_react.useState)(0);
	const messagesEnd = (0, import_react.useRef)(null);
	const messageInput = (0, import_react.useRef)(null);
	const rtc = (0, import_react.useRef)(null);
	const localStream = (0, import_react.useRef)(null);
	const remoteVideo = (0, import_react.useRef)(null);
	const localVideo = (0, import_react.useRef)(null);
	const pendingOffer = (0, import_react.useRef)(null);
	const pendingIce = (0, import_react.useRef)([]);
	const currentPeer = (0, import_react.useRef)(null);
	const signals = (0, import_react.useRef)({});
	const answeredAt = (0, import_react.useRef)(null);
	const loadContacts = (0, import_react.useCallback)(async (userId) => {
		const { data, error } = await supabase.from("contacts").select("contact_id,saved_name").eq("owner_id", userId).order("saved_name");
		if (error) {
			toast.error("Your contacts could not be loaded.");
			return;
		}
		setContacts(data ?? []);
	}, []);
	const loadProfile = (0, import_react.useCallback)(async (userId) => {
		const { data, error } = await supabase.from("profiles").select("id,display_name,avatar_url,bio,username,created_at").eq("id", userId).maybeSingle();
		if (error) toast.error("Your profile could not be loaded.");
		setProfile(data);
		setProfileLoaded(true);
	}, []);
	(0, import_react.useEffect)(() => {
		let active = true;
		supabase.auth.getSession().then(({ data }) => {
			if (!active) return;
			const current = data.session?.user;
			setUser(current ? {
				id: current.id,
				email: current.email
			} : null);
			setLoading(false);
		});
		const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
			if (event === "PASSWORD_RECOVERY") setRecovery(true);
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			const current = session?.user;
			setUser(current ? {
				id: current.id,
				email: current.email
			} : null);
			if (!current) {
				setProfile(null);
				setContacts([]);
				setSelected(null);
				setMessages([]);
				endCall(false);
				setRecovery(false);
			}
		});
		return () => {
			active = false;
			listener.subscription.unsubscribe();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		loadProfile(user.id);
		loadContacts(user.id);
		supabase.rpc("has_role", { _role: "admin" }).then(({ data, error }) => {
			setIsAdmin(!error && Boolean(data));
		});
	}, [
		user,
		loadContacts,
		loadProfile
	]);
	const activeContact = contacts.find((contact) => contact.contact_id === selected?.contact_id) ?? selected;
	(0, import_react.useEffect)(() => {
		let alive = true;
		let channel = null;
		const open = async () => {
			if (!user || !activeContact) {
				setMessages([]);
				setBlocked(false);
				return;
			}
			const { data: blockRows, error: blockError } = await supabase.from("blocks").select("blocked_id").eq("blocker_id", user.id).eq("blocked_id", activeContact.contact_id);
			if (!alive) return;
			if (blockError) toast.error("Block status could not be checked.");
			setBlocked(Boolean(blockRows?.length));
			const { data: conversationId, error: conversationError } = await supabase.rpc("get_or_create_direct_conversation", { other_user_id: activeContact.contact_id });
			if (!alive) return;
			if (conversationError || !conversationId) {
				toast.error(conversationError?.message ?? "This conversation could not be opened.");
				setMessages([]);
				return;
			}
			const { data: history, error: historyError } = await supabase.from("messages").select("*").eq("conversation_id", conversationId).order("created_at");
			if (!alive) return;
			if (historyError) toast.error("Messages could not be loaded.");
			setMessages(history ?? []);
			channel = supabase.channel(`whispr-messages-${conversationId}-${Math.random().toString(36).slice(2)}`).on("postgres_changes", {
				event: "INSERT",
				schema: "public",
				table: "messages",
				filter: `conversation_id=eq.${conversationId}`
			}, (payload) => {
				const incoming = payload.new;
				setMessages((current) => current.some((item) => item.id === incoming.id) ? current : [...current, incoming]);
			}).subscribe();
		};
		open();
		return () => {
			alive = false;
			if (channel) supabase.removeChannel(channel);
		};
	}, [user, activeContact?.contact_id]);
	(0, import_react.useEffect)(() => {
		messagesEnd.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages]);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		const channel = supabase.channel(`calls-${user.id}`, { config: { private: true } }).on("broadcast", { event: "signal" }, async ({ payload }) => {
			const signal = payload;
			if (!signal.from || signal.from === user.id) return;
			if (signal.kind === "offer") {
				if (currentPeer.current) {
					await sendSignal(signal.from, { kind: "end" });
					return;
				}
				currentPeer.current = signal.from;
				pendingOffer.current = signal.description ?? null;
				setCallVideo(Boolean(signal.video));
				setCallState({
					peerId: signal.from,
					name: contacts.find((contact) => contact.contact_id === signal.from)?.saved_name ?? `@${signal.name || "whispr user"}`,
					incoming: true
				});
				setCallStatus(`Incoming ${signal.video ? "video" : "voice"} call`);
			} else if (signal.from === currentPeer.current && signal.kind === "answer" && rtc.current && signal.description) {
				await rtc.current.setRemoteDescription(signal.description);
				for (const candidate of pendingIce.current) await rtc.current.addIceCandidate(candidate);
				pendingIce.current = [];
			} else if (signal.from === currentPeer.current && signal.kind === "ice" && signal.candidate) if (rtc.current?.remoteDescription) await rtc.current.addIceCandidate(signal.candidate);
			else pendingIce.current.push(signal.candidate);
			else if (signal.from === currentPeer.current && signal.kind === "end") endCall(false);
		}).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, [user, contacts]);
	(0, import_react.useEffect)(() => {
		if (!callState || callState.incoming || !answeredAt.current) return;
		const interval = window.setInterval(() => setCallTick(Date.now()), 1e3);
		return () => window.clearInterval(interval);
	}, [callState]);
	function endCall(notify = true) {
		const peerId = currentPeer.current;
		if (notify && peerId) sendSignal(peerId, { kind: "end" });
		rtc.current?.close();
		rtc.current = null;
		localStream.current?.getTracks().forEach((track) => track.stop());
		localStream.current = null;
		currentPeer.current = null;
		pendingOffer.current = null;
		pendingIce.current = [];
		answeredAt.current = null;
		if (remoteVideo.current) remoteVideo.current.srcObject = null;
		if (localVideo.current) localVideo.current.srcObject = null;
		setCallState(null);
		setCallStatus("");
	}
	async function sendSignal(to, signal) {
		let channel = signals.current[to];
		if (!channel) {
			channel = supabase.channel(`calls-${to}`, { config: { private: true } });
			signals.current[to] = channel;
			await new Promise((resolve) => {
				channel?.subscribe((status) => {
					if (status === "SUBSCRIBED" || status === "CHANNEL_ERROR" || status === "TIMED_OUT") resolve();
				});
			});
		}
		await channel.send({
			type: "broadcast",
			event: "signal",
			payload: {
				...signal,
				from: user?.id,
				name: profile?.username ?? "Whispr user"
			}
		});
	}
	async function connectCall(withVideo) {
		if (!currentPeer.current || !navigator.mediaDevices?.getUserMedia) throw new Error("Calls need microphone access in a supported browser.");
		const stream = await navigator.mediaDevices.getUserMedia({
			audio: true,
			video: withVideo
		});
		localStream.current = stream;
		if (localVideo.current && withVideo) localVideo.current.srcObject = stream;
		const connection = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
		rtc.current = connection;
		stream.getTracks().forEach((track) => connection.addTrack(track, stream));
		connection.ontrack = (event) => {
			if (remoteVideo.current) remoteVideo.current.srcObject = event.streams[0] ?? null;
		};
		connection.onicecandidate = (event) => {
			if (event.candidate && currentPeer.current) sendSignal(currentPeer.current, {
				kind: "ice",
				candidate: event.candidate.toJSON()
			});
		};
		connection.onconnectionstatechange = () => {
			if (connection.connectionState === "connected") {
				answeredAt.current = Date.now();
				setCallStatus("Connected");
			} else if (connection.connectionState === "failed" || connection.connectionState === "closed") endCall(false);
		};
		return connection;
	}
	async function startCall(video) {
		if (!activeContact || currentPeer.current) return;
		currentPeer.current = activeContact.contact_id;
		setCallVideo(video);
		setCallState({
			peerId: activeContact.contact_id,
			name: activeContact.saved_name,
			incoming: false
		});
		setCallStatus(video ? "Starting video call…" : "Starting voice call…");
		try {
			const connection = await connectCall(video);
			const offer = await connection.createOffer();
			await connection.setLocalDescription(offer);
			const description = connection.localDescription?.toJSON();
			if (description) await sendSignal(activeContact.contact_id, {
				kind: "offer",
				video,
				description
			});
			setCallStatus("Calling…");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not start your call.");
			endCall(false);
		}
	}
	async function acceptCall() {
		const peerId = currentPeer.current;
		if (!peerId || !pendingOffer.current) return;
		setCallStatus("Connecting…");
		try {
			const connection = await connectCall(callVideo);
			await connection.setRemoteDescription(pendingOffer.current);
			for (const candidate of pendingIce.current) await connection.addIceCandidate(candidate);
			pendingIce.current = [];
			const answer = await connection.createAnswer();
			await connection.setLocalDescription(answer);
			const description = connection.localDescription?.toJSON();
			if (!description) throw new Error("The call could not be prepared.");
			await sendSignal(peerId, {
				kind: "answer",
				description
			});
			setCallState((state) => state ? {
				...state,
				incoming: false
			} : state);
			setCallStatus("Connecting…");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not connect the call.");
			endCall(true);
		}
	}
	async function submitAuth(event) {
		event.preventDefault();
		setBusy(true);
		setAuthError("");
		const result = loginMode === "signup" ? await supabase.auth.signUp({
			email: email.trim(),
			password,
			options: { data: { display_name: email.split("@")[0] ?? "Whispr user" } }
		}) : await supabase.auth.signInWithPassword({
			email: email.trim(),
			password
		});
		setBusy(false);
		if (result.error) setAuthError(result.error.message);
		else if (loginMode === "signup" && !result.data.session) setAuthError("Check your email to confirm your account, then sign in.");
	}
	async function googleSignIn() {
		const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
		if (result.error) setAuthError(result.error.message);
	}
	async function sendPasswordReset() {
		setAuthError("");
		if (!email.trim()) {
			setAuthError("Enter your email address first.");
			return;
		}
		const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: window.location.origin });
		if (error) setAuthError(error.message);
		else setResetSent(true);
	}
	async function submitNewPassword(event) {
		event.preventDefault();
		setRecoveryError("");
		const { error } = await supabase.auth.updateUser({ password: newPassword });
		if (error) setRecoveryError(error.message);
		else {
			setRecovery(false);
			setNewPassword("");
			toast.success("Your password has been updated.");
		}
	}
	async function lovableSignIn() {
		const result = await lovable.auth.signInWithOAuth("lovable", { redirect_uri: window.location.origin });
		if (result.error) setAuthError(result.error.message);
	}
	async function submitUsername(event) {
		event.preventDefault();
		setUsernameError("");
		if (!isValidUsername(username)) {
			setUsernameError("Use 3–20 letters, numbers, or underscores.");
			return;
		}
		setBusy(true);
		const { error } = await supabase.rpc("set_username", { u: username.trim() });
		setBusy(false);
		if (error) setUsernameError(error.message);
		else {
			toast.success(`Welcome to Whispr, @${username.trim()}`);
			if (user) loadProfile(user.id);
		}
	}
	async function submitSearch(event) {
		event.preventDefault();
		if (searchName.trim().length < 1) return;
		const { data, error } = await supabase.rpc("search_users", { q: searchName.trim() });
		if (error) toast.error(error.message);
		else setHits(data ?? []);
	}
	async function saveContact(event) {
		event.preventDefault();
		if (!picked || !user || !savedName.trim()) return;
		const { error } = await supabase.rpc("add_contact_by_username", {
			uname: picked.username,
			name: savedName.trim()
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		const contact = {
			contact_id: picked.id,
			saved_name: savedName.trim()
		};
		await loadContacts(user.id);
		setSelected(contact);
		setMobileChat(true);
		setAddOpen(false);
		setSearchName("");
		setHits([]);
		setPicked(null);
		setSavedName("");
		toast.success("Contact saved");
	}
	async function sendMessage(event) {
		event.preventDefault();
		if (!user || !activeContact || !messageInput.current) return;
		const body = messageInput.current.value.trim();
		if (!body) return;
		messageInput.current.value = "";
		const { data: conversationId, error: conversationError } = await supabase.rpc("get_or_create_direct_conversation", { other_user_id: activeContact.contact_id });
		if (conversationError || !conversationId) {
			toast.error(conversationError?.message ?? "The message could not be sent.");
			return;
		}
		const { error } = await supabase.from("messages").insert({
			conversation_id: conversationId,
			sender_id: user.id,
			body
		});
		if (error) {
			if (messageInput.current) messageInput.current.value = body;
			toast.error(error.message === "new row violates row-level security policy for table \"messages\"" ? "This message could not be sent. Check your block settings." : "Message not delivered.");
		}
	}
	async function toggleBlock() {
		if (!user || !activeContact) return;
		const result = blocked ? await supabase.from("blocks").delete().eq("blocker_id", user.id).eq("blocked_id", activeContact.contact_id) : await supabase.from("blocks").insert({
			blocker_id: user.id,
			blocked_id: activeContact.contact_id
		});
		if (result.error) toast.error(result.error.message);
		else {
			setBlocked(!blocked);
			toast.success(blocked ? "Contact unblocked" : "Contact blocked");
		}
	}
	async function reportContact() {
		if (!user || !activeContact) return;
		const reason = window.prompt("What would you like to report?");
		if (!reason?.trim()) return;
		const lastMessage = [...messages].reverse().find((message) => message.sender_id === activeContact.contact_id);
		const { error } = await supabase.from("reports").insert({
			reporter_id: user.id,
			reported_user_id: activeContact.contact_id,
			message_id: lastMessage?.id ?? null,
			reason: reason.trim()
		});
		if (error) toast.error(error.message);
		else toast.success("Report received. Thank you.");
	}
	async function openFounder() {
		setFounderOpen(true);
		setFounderError("");
		setFounderData(null);
	}
	async function loadFounderData(pin) {
		setFounderError("");
		const { data: isAdmin, error: roleError } = await supabase.rpc("has_role", { _role: "admin" });
		if (roleError || !isAdmin) {
			setFounderError("Founder access is not assigned to this account.");
			return;
		}
		const [stats, users, reports] = await Promise.all([
			supabase.rpc("founder_stats", { pin }),
			supabase.rpc("founder_users", { pin }),
			supabase.rpc("founder_reports", { pin })
		]);
		if (stats.error || users.error || reports.error) {
			setFounderError(stats.error?.message ?? users.error?.message ?? reports.error?.message ?? "Founder access could not be verified.");
			return;
		}
		setFounderData({
			stats: stats.data,
			users: users.data,
			reports: reports.data
		});
	}
	async function setupFounderCode() {
		if (founderPin.length < 12) {
			setFounderError("Use a private code with at least 12 characters.");
			return;
		}
		setFounderError("");
		const { error } = await supabase.rpc("founder_setup", { pin: founderPin });
		if (error) {
			setFounderError(error.message);
			return;
		}
		toast.success("Founder code created. Keep it private.");
		loadFounderData(founderPin);
	}
	async function banUser(id, ban) {
		const { error } = await supabase.rpc("founder_set_ban", {
			pin: founderPin,
			uid: id,
			ban
		});
		if (error) toast.error(error.message);
		else loadFounderData(founderPin);
	}
	async function resolveReport(id) {
		const { error } = await supabase.rpc("founder_resolve", {
			pin: founderPin,
			rid: id
		});
		if (error) toast.error(error.message);
		else loadFounderData(founderPin);
	}
	const filteredContacts = contacts.filter((contact) => contact.saved_name.toLowerCase().includes(query.toLowerCase()));
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-serif text-2xl text-primary",
			children: "Whispr"
		})
	});
	if (recovery) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "auth-screen recovery-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "auth-mark",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "brand-glyph",
					children: "w"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Whispr" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "auth-copy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "A fresh start"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
						"Let's get you",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"back to your people."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Choose a new password for your Whispr account." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "auth-panel",
				"aria-label": "Set a new password",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "Account recovery"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Set a new password." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "auth-subtitle",
						children: "Use at least 6 characters."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "auth-form",
						onSubmit: (event) => void submitNewPassword(event),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "field-label",
								htmlFor: "recovery-password",
								children: "New password"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "recovery-password",
								type: "password",
								autoComplete: "new-password",
								minLength: 6,
								value: newPassword,
								onChange: (event) => setNewPassword(event.target.value),
								required: true
							}),
							recoveryError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "form-error",
								role: "alert",
								children: recoveryError
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full auth-submit",
								type: "submit",
								children: "Update password"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "auth-footer",
				children: "Private by design. Made for the people who matter."
			})
		]
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "auth-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "auth-photo-pane",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: whispr_conversation_default,
					width: 1200,
					height: 1408,
					alt: ""
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "auth-mark",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "brand-glyph",
					children: "w"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Whispr" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "auth-copy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "A little closer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
						"Good conversations",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"start here."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Find your people. Make a moment of it." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "auth-panel",
				"aria-label": "Sign in to Whispr",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-kicker",
						children: "Welcome to Whispr"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: loginMode === "signin" ? "Come on in." : "Make it yours." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "auth-subtitle",
						children: loginMode === "signin" ? "Sign in to pick up where you left off." : "Create your account and find your people."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "social-buttons",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "w-full",
							onClick: () => void googleSignIn(),
							children: "Continue with Google"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "w-full",
							onClick: () => void lovableSignIn(),
							children: "Continue with Lovable"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "auth-divider",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
							"or use email",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "auth-form",
						onSubmit: (event) => void submitAuth(event),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "field-label",
								htmlFor: "whispr-email",
								children: "Email address"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "whispr-email",
								type: "email",
								autoComplete: "email",
								placeholder: "you@example.com",
								value: email,
								onChange: (event) => setEmail(event.target.value),
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "field-label",
								htmlFor: "whispr-password",
								children: "Password"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "whispr-password",
								type: "password",
								autoComplete: loginMode === "signup" ? "new-password" : "current-password",
								placeholder: "At least 6 characters",
								minLength: 6,
								value: password,
								onChange: (event) => setPassword(event.target.value),
								required: true
							}),
							authError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "form-error",
								role: "alert",
								children: authError
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full auth-submit",
								type: "submit",
								disabled: busy,
								children: busy ? "One moment…" : loginMode === "signin" ? "Sign in" : "Create account"
							})
						]
					}),
					loginMode === "signin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "auth-switch",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void sendPasswordReset(),
							children: "Forgot your password?"
						})
					}),
					resetSent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "auth-switch",
						role: "status",
						children: "If that email has an account, a reset link is on its way."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "auth-switch",
						children: [
							loginMode === "signin" ? "New to Whispr?" : "Already have an account?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setLoginMode(loginMode === "signin" ? "signup" : "signin");
									setAuthError("");
									setResetSent(false);
								},
								children: loginMode === "signin" ? "Create an account" : "Sign in"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "auth-footer",
				children: "Private by design. Made for the people who matter."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: `messenger ${mobileChat ? "show-chat" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "contact-pane",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "side-header",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand-button",
							"aria-label": "Whispr",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "brand-glyph small",
								children: "w"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Whispr" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "header-actions",
							children: [
								isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Founder dashboard",
									title: "Founder dashboard",
									onClick: () => void openFounder(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Add contact",
									title: "Add contact",
									onClick: () => setAddOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Sign out",
									title: "Sign out",
									onClick: () => void supabase.auth.signOut(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {})
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "self-profile",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								className: "self-avatar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: initials(profile?.username || profile?.display_name || user.email || "W") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "self-copy",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: profile?.display_name || user.email?.split("@")[0] || "Your account" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile?.username ? `@${profile.username}` : "Make your name yours" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleUserRound, {
								"aria-hidden": "true",
								className: "self-icon"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "contact-search",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							size: 17,
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Search contacts",
							placeholder: "Search conversations",
							value: query,
							onChange: (event) => setQuery(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "contact-section-label",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Your conversations" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: filteredContacts.length })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
						className: "contact-list",
						children: filteredContacts.length ? filteredContacts.map((contact, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: `contact-row ${activeContact?.contact_id === contact.contact_id ? "selected" : ""}`,
							type: "button",
							onClick: () => {
								setSelected(contact);
								setMobileChat(true);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									className: `contact-avatar avatar-tone-${index % 4}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: initials(contact.saved_name) })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "contact-row-copy",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: contact.saved_name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Start a conversation" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "contact-dot",
									"aria-hidden": "true"
								})
							]
						}, contact.contact_id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "contact-empty",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { size: 24 }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: query ? "No names found" : "A little quiet here" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: query ? "Try another search." : "Add a friend to start your first conversation." }),
								!query && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setAddOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "Add a contact"]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "side-footer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "online-mark" }), "All your conversations, in one place"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "conversation-pane",
				children: activeContact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "conversation-header",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mobile-back",
								variant: "ghost",
								size: "icon",
								"aria-label": "Back to conversations",
								onClick: () => setMobileChat(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								className: "chat-avatar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: initials(activeContact.saved_name) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "chat-person",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: activeContact.saved_name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: blocked ? "Contact blocked" : "Your conversation" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "chat-actions",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": "Start voice call",
										title: "Voice call",
										disabled: blocked || Boolean(callState),
										onClick: () => void startCall(false),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": "Start video call",
										title: "Video call",
										disabled: blocked || Boolean(callState),
										onClick: () => void startCall(true),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "chat-menu",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
											"aria-label": "Conversation options",
											title: "Conversation options",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "chat-menu-items",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => void toggleBlock(),
												children: blocked ? "Unblock contact" : "Block contact"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => void reportContact(),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { size: 15 }), "Report contact"]
											})]
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "conversation-date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Just between you two" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
						className: "message-scroll",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "message-list",
							children: [blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "chat-notice",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { size: 18 }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "You blocked this contact" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unblock them to send a message or start a call." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => void toggleBlock(),
										children: "Unblock contact"
									})
								]
							}) : messages.length ? messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `message-bubble ${message.sender_id === user.id ? "mine" : "theirs"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: message.body }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { children: formatTime(message.created_at) })]
							}, message.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "chat-notice welcome-note",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { size: 22 }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["Say hello to ", activeContact.saved_name] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Your conversation starts with one message." })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: messagesEnd })]
						})
					}),
					!blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "composer",
						onSubmit: (event) => void sendMessage(event),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							ref: messageInput,
							"aria-label": "Your message",
							placeholder: "Write a message…",
							rows: 1,
							maxLength: 5e3,
							onKeyDown: (event) => {
								if (event.key === "Enter" && !event.shiftKey) {
									event.preventDefault();
									event.currentTarget.form?.requestSubmit();
								}
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "icon",
							"aria-label": "Send message",
							title: "Send message",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})
						})]
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "welcome-pane",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "welcome-mark",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
								size: 32,
								strokeWidth: 1.5
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "section-kicker",
							children: "The good stuff is in the little things"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
							"Make room for",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "a real conversation." })
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Choose a contact to begin, or bring someone new into your circle." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => setAddOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), "Add a contact"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "welcome-bottom",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "One-to-one conversations, kept simple" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: profileLoaded && !profile?.username,
				onOpenChange: () => {},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "whispr-dialog",
					onEscapeKeyDown: (event) => event.preventDefault(),
					onInteractOutside: (event) => event.preventDefault(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "dialog-symbol",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleUserRound, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Make yourself at home" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Choose a username so friends can find you on Whispr." })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "dialog-form",
						onSubmit: (event) => void submitUsername(event),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "field-label",
								htmlFor: "whispr-username",
								children: "Your username"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "whispr-username",
								value: username,
								onChange: (event) => setUsername(event.target.value),
								autoComplete: "username",
								autoCapitalize: "none",
								maxLength: 20,
								placeholder: "e.g. amina_k"
							}),
							usernameError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "form-error",
								role: "alert",
								children: usernameError
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: busy,
								children: busy ? "Saving…" : "Choose username"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: addOpen,
				onOpenChange: (open) => {
					setAddOpen(open);
					if (!open) {
						setPicked(null);
						setHits([]);
						setSearchName("");
						setSavedName("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "whispr-dialog",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "dialog-symbol",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add someone to your circle" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Find a Whispr friend by their username." })
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "search-form",
							onSubmit: (event) => void submitSearch(event),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Search by username",
								autoCapitalize: "none",
								placeholder: "Search username",
								value: searchName,
								onChange: (event) => setSearchName(event.target.value.replace(/[^A-Za-z0-9_]/g, ""))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								size: "icon",
								"aria-label": "Search",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "search-results",
							children: [hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `search-hit ${picked?.id === hit.id ? "active" : ""}`,
								type: "button",
								onClick: () => {
									setPicked(hit);
									setSavedName(hit.username);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
										className: "contact-avatar",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: initials(hit.username) })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["@", hit.username] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Whispr member" })] }),
									picked?.id === hit.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 18 })
								]
							}, hit.id)), searchName && !hits.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "search-help",
								children: "Search for a username to find someone."
							})]
						}),
						picked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "dialog-form",
							onSubmit: (event) => void saveContact(event),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "field-label",
									htmlFor: "saved-contact-name",
									children: "Save this contact as"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "saved-contact-name",
									maxLength: 40,
									value: savedName,
									onChange: (event) => setSavedName(event.target.value),
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									children: "Save contact"
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: founderOpen,
				onOpenChange: (open) => {
					setFounderOpen(open);
					if (!open) {
						setFounderPin("");
						setFounderData(null);
						setFounderError("");
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "whispr-dialog founder-dialog",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "dialog-symbol",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Founder dashboard" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Private moderation tools for assigned administrators." })
					] }), !founderData ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "dialog-form",
						onSubmit: (event) => {
							event.preventDefault();
							loadFounderData(founderPin);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "field-label",
								htmlFor: "founder-code",
								children: "Founder code"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "founder-code",
								type: "password",
								autoComplete: "off",
								value: founderPin,
								onChange: (event) => setFounderPin(event.target.value),
								required: true
							}),
							founderError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "form-error",
								role: "alert",
								children: founderError
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								children: "Unlock dashboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								disabled: founderPin.length < 12,
								onClick: () => void setupFounderCode(),
								children: "Create first founder code"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "founder-code-note",
								children: "Available only to an assigned administrator. Use at least 12 characters."
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FounderDashboard, {
						data: founderData,
						onBan: (id, ban) => void banUser(id, ban),
						onResolve: (id) => void resolveReport(id)
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(callState),
				onOpenChange: (open) => {
					if (!open) endCall();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "call-dialog",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: callState?.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: callStatus })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `call-stage ${callVideo ? "video-call" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									ref: remoteVideo,
									autoPlay: true,
									playsInline: true,
									className: "remote-video"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									ref: localVideo,
									autoPlay: true,
									playsInline: true,
									muted: true,
									className: "local-video"
								}),
								!callVideo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "call-avatar",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
										className: "call-avatar-image",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, { children: initials(callState?.name ?? "W") })
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "call-controls",
							children: [callState?.incoming && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => void acceptCall(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 16 }), "Answer"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "destructive",
								onClick: () => endCall(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 17 }), "End call"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "call-footnote",
							children: "Calls work best on a reliable network. Camera and microphone access are needed."
						})
					]
				})
			})
		]
	});
}
function FounderDashboard({ data, onBan, onResolve }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "founder-content",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "founder-stats",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Members" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.stats.users })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "New today" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.stats.new_today })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Messages" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.stats.messages })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", { children: ["Open reports ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data.reports.length })] }),
			data.reports.length ? data.reports.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "founder-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["@", report.reported || "member"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [report.reason, report.message ? ` — “${report.message}”` : ""] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["Reported by @", report.reporter || "member"] })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "destructive",
					onClick: () => onBan(report.reported_id, true),
					children: "Ban"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => onResolve(report.id),
					children: "Dismiss"
				})] })]
			}, report.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "founder-empty",
				children: "No open reports."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", { children: ["Members ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data.users.length })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "founder-users",
				children: data.users.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "founder-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["@", member.username || "no username"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: member.email })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: member.banned ? "outline" : "destructive",
						onClick: () => onBan(member.id, !member.banned),
						children: member.banned ? "Unban" : "Ban"
					})]
				}, member.id))
			})
		]
	});
}
function initials(value) {
	return (value.replace(/^@/, "").trim()[0] ?? "W").toUpperCase();
}
function formatTime(value) {
	return new Intl.DateTimeFormat(void 0, {
		hour: "numeric",
		minute: "2-digit"
	}).format(new Date(value));
}
//#endregion
export { Whispr as component };
